#define _XOPEN_SOURCE	500

#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>

